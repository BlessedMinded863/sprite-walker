FATAL INSTINCT SPRITE ANIMATOR V10.1
=====================================

PURPOSE
-------
Polish the source Claw Slash motion so regenerated slash frames read more clearly
at SNES size.

WHAT CHANGED
------------
- Reduced body dip / crouch during slash
- Larger high/back wind-up
- Longer forward slash travel
- Clearer follow-through
- Stronger default slash preset

NEW DEFAULT SLASH PRESET
------------------------
windup      62
reach       100
strikeAngle 8
twist       22
attackLean  3
hipDrive    7
claw       -30
guard      14

USE NEXT
--------
1. Load approved Marius art
2. Load corrected rig
3. Animation: Claw Slash
4. Faces Right
5. Front Limb
6. Load Mode Preset
7. Preview Motion
8. Generate 4 Frames
9. Replace slash_01.png through slash_04.png if improved

SHA-256
-------
cb05b89ad09d0e9fcd6a1365160895edac49ff5248c82a62e90b12760c4bbe9e
